﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PhoneBook2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Connection.FillListboxName(listBox);
        }

        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            
        }

        private void viewBtn_Click(object sender, RoutedEventArgs e)
        {
            if (viewBtn.Content.ToString() == "Részletes nézet")
            {
                viewBtn.Content = "Minimalista nézet";
                Connection.FillListboxFull(listBox);
            }
            else
            {
                viewBtn.Content = "Részletes nézet";
                Connection.FillListboxName(listBox);
            }
            
            
        }

        private void newBtn_Click(object sender, RoutedEventArgs e)
        {
            NewContact addWin = new NewContact();
            addWin.ShowDialog();
            Connection.FillListboxName(listBox);
        }

        private void delBtn_Click(object sender, RoutedEventArgs e)
        {
            Connection.RemoveContact(listBox);
        }

        private void editBtn_Click(object sender, RoutedEventArgs e)
        {
            EditContact editWin = new EditContact(listBox.SelectedValue.ToString());
            editWin.ShowDialog();
            

        }
    }
}
