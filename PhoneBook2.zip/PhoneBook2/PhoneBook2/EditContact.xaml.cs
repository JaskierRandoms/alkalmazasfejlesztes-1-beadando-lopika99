﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PhoneBook2
{
    /// <summary>
    /// Interaction logic for EditContact.xaml
    /// </summary>
    public partial class EditContact : Window
    {
        string id;
        public EditContact(string id)
        {
            InitializeComponent();
            Connection.FillComboboxType(typeCb);
            Connection.FillEditFull(nameTb, numTb, typeCb, id);
            this.id = id;
        }

        private void editBtn_Click(object sender, RoutedEventArgs e)
        {
            Connection.EditContact(nameTb, numTb, typeCb, id);
        }
    }
}