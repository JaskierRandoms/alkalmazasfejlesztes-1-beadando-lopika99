﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace PhoneBook2
{
    class Connection
    {
        private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");

        public static void Connect()
        {
            try
            {
                conn.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void Close()
        {
            conn.Close();
        }

        public static void FillListboxName(ListBox lb)
        {
            string cmd = string.Format("Select id, CONCAT_WS(' ', name) as ossz FROM contacts");
            MySqlDataAdapter da = new MySqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns["ossz"].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }

        public static void FillListboxFull(ListBox lb)
        {
            string cmd = string.Format("Select id, CONCAT_WS(' ', name, number, type) as ossz FROM contacts");
            MySqlDataAdapter da = new MySqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns["ossz"].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }

        public static void FillComboboxType(ComboBox cb)
        {
            string cmd = string.Format("Select DISTINCT CONCAT_WS(' ', type) as ossz FROM contacts");
            MySqlDataAdapter da = new MySqlDataAdapter(cmd, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cb.ItemsSource = ds.Tables[0].DefaultView;
            cb.DisplayMemberPath = ds.Tables[0].Columns[0].ToString();
            cb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }
        public static void FillEditFull(TextBox tb, TextBox tb2, ComboBox cb, string id)
        {
            string cmd = string.Format("Select name, number, type FROM contacts WHERE id='{0}'", id);
            MySqlCommand co = new MySqlCommand(cmd, conn);
            Connection.Connect();
            MySqlDataReader dr = co.ExecuteReader();
            if (dr.Read())
            {
                tb.Text = dr.GetString(0);
                tb2.Text = dr.GetString(1);
            }
            Connection.Close();
        }

        public static void EditContact(TextBox tb, TextBox tb2, ComboBox cb, string id)
        {
            string cmd = string.Format("UPDATE contacts SET name='{0}', number='{1}', type='{2}' WHERE id='{3}'", tb.Text.ToString(), tb2.Text.ToString(), cb.SelectedValue.ToString(), id);
            MySqlCommand co = new MySqlCommand(cmd, conn);
            MessageBox.Show(cmd);
            Connection.Connect();
            try
            {
                co.ExecuteNonQuery();
                MessageBox.Show("Elérhetőség sikeresen módósítva!!");
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            Connection.Close();
        }

        public static void AddContact(TextBox tb, TextBox tb2, ComboBox cb)
        {
            string cmd = string.Format("INSERT INTO contacts(id, name, number,type) VAlUES('', '{0}', '{1}', '{2}')", tb.Text, tb2.Text, cb.SelectedValue.ToString());
            MySqlCommand co = new MySqlCommand(cmd, conn);
            if (tb.Text == "" || tb2.Text == "")
            {
                MessageBox.Show("Hiányos elérhetőséget nem lehet menteni!! " +
                                "Nevet és telefonszámot kötelező megadni!! ");
            }
            else
            {
                try
                {
                    co.ExecuteNonQuery();
                    MessageBox.Show("Elérhetőség felvéve a telefonkönyvbe!!");
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            
        }

        public static void RemoveContact(ListBox lb)
        {
            string cmd = string.Format("DELETE FROM `contacts` WHERE `name` = '{0}';", lb.SelectedValue.ToString());
            MySqlCommand co = new MySqlCommand(cmd, conn);
            Connection.Connect();
            try
            {
                co.ExecuteNonQuery();
                MessageBox.Show("Sikeres törlés!!");
                Connection.FillListboxName(lb);
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
